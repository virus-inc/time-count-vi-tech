<?php
/**
 * @package time-count-vi-tech
 * @version 1.0
 */
/*
Plugin Name: Time Count by Virus Inc.
Plugin URI: http://virusincbd.com
Description: Count time how many time user stay on your site.
Author: VI Tech
Version: 1.0
Author URI: https://www.facebook.com/VirusIncorporation/
*/
session_start();
date_default_timezone_set(Asia/Dhaka);
function countDownDate()
{
    if(isset($_SESSION['usertime']))
    {
        $time = $_SESSION['usertime'];
        return $time;
    }
    else
    {
        $_SESSION['usertime'] = time();
        $time = $_SESSION['usertime'];
        return $time;
    } 
}

function javascript_ud()
{
?>
    <script>
    timeZone: "Asia/Dhaka"
    var countDownDate = <?php echo countDownDate(); ?>;
    var x = setInterval(function() {
      var now = new Date().getTime();
      var distance = now - (countDownDate * 1000);
      var days = Math.floor(distance / ((1000 * 60 * 60 * 24)));
      var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
      document.getElementById("time_show_ud").innerHTML =  hours + "h "+ minutes + "m " + seconds + "s ";
    
    }, 1000);
    </script>
<?php
}
add_filter( "wp_head", "javascript_ud" );

function show_ud()
{
    
    $output = "<p id='time_show_ud'></p>";
    return $output;
    
}

?>
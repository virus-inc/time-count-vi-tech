=== Time Count by Virus Inc. ===
Contributors: VI Tech
Tags: Count how many time user stay on your site.
Requires at least: 3.8
Tested up to: 5.0.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Count how many time user stay on your site.
Put this code anywhere in your sit <p id="time_show_ud"></p>